
# 面试

## Python后端
1.  Python
    装饰器
    生成器
    多进程多线程
    算法
    面向对象

2.  数据库
    缓存
    消息队列
    网络

3.  项目经验
    自我介绍
    想好了再说


## Python Web开发

    爬虫
    Python web

    RESTful API  -> Flask + sqlAlchemy


## 学习方法

给自己列计划

给自己立里程碑  --> 仪式感






