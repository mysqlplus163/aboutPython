# Python全栈班前端分享课

1. 前端那些事儿
2. Bootstrap简单使用示范
3. SweetAlert简单使用示范


## 前端那些事儿
* HTML/CSS/JS
* jQuery
* Chrome

## Bootstarp简单使用示范

* 栅格系统
1. 媒体查询示例
2. column综合示例

* 使用Bootstrap搭建页面示范

1. 5分钟搭建Django项目框架

    - settings/model/view/url/admin
    - PyCharm使用技巧（Live Templates/Reformat Code）

2. 前端搭建页面
    - nav
    - panel+table
    - modal
    - DateTime Picker


## SweetAlert简单使用示范
1. 简单示例演示

2. 配合Django AJAX 使用示例

